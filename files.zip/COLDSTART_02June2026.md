# COLD START — Morning of 2 June 2026
**For:** New Claude seat (any seat in AIMM chain)  
**Read time:** 90 seconds  
**Purpose:** Get up to speed instantly, no re-explaining

---

## Who you're talking to
**Kevin Lelitte** — Manager/Director, HR Systems team, University of Oxford.  
First week back after 4-week medical leave (surgery 5 May). Still finding his feet.

## What happened yesterday (1 June — his first day back)
- Full inbox triage done — briefing saved to his Work Folders
- Clockify time logged for the day (7h 15m via Timesheet)
- "Weekly Standard" Clockify template created — 4 rows, saves him time weekly
- Command Centre HTML updated (but needs a full redesign — see below)

---

## TODAY'S PRIORITIES (2 June 2026)

### 🔴 Urgent — action today
1. **RSVP Eploy Hold meeting** — today at 11am. He may need to reply before it starts.
2. **Design session: Command Centre v2** — booked for today. This is a Claude session to redesign the Command Centre HTML from scratch.
3. **Chase Marie Cooksey** — PXD DPIA sign-off needed before 5 June
4. **Chase Marie Cooksey** — DTP1092 proposal sign-off needed before 5 June
5. **Teams Telephony** — deadline passed yesterday. Check with Marie / Neil Clarke what happened.

### 🟡 This week
- FlexPoints case #68899229 — authorise in portal before 11 June
- Conor O'Brien (Access Group) back from leave 11 June — prep for handoff

---

## COMMAND CENTRE REDESIGN (today's main build task)

Kevin wants a full redesign of `command_centre_refreshed.html`. Current version described as "very clunky, very old."

**Design brief:**
- Modern, clean, confident — not a generic AI dashboard
- Works as a Claude artifact (inline HTML/CSS/JS, no external deps except cdnjs)
- The `sendPrompt()` function is available for buttons
- Keep core structure: header, metric cards, launch buttons, open actions, meetings, VIP contacts
- Make it feel like a premium personal ops tool, not a template

**What to keep:**
- Morning Briefing, VIP Check, Calendar Check, Log Today buttons (keep these launch buttons)
- Open actions panel (update to June 2 content)
- VIP contacts (Marie Cooksey, Simon Burford)
- Calendar hard rules panel
- Live clock

**What to change:**
- Full visual redesign — typography, colours, spacing, layout
- Remove Granola references
- Update meetings panel to this week (Jun 2–5)
- Update open actions to current June list
- Consider adding a "Clockify this week" summary row
- Make launch buttons more visually prominent

**Read the frontend-design skill first:** `/mnt/skills/public/frontend-design/SKILL.md`

---

## CLOCKIFY — ONGOING PROCESS

**Kevin's daily Clockify process (established yesterday):**
1. Go to `https://app.clockify.me/timesheet`
2. Monday only: click Apply on **"Weekly Standard"** template
3. Fill in today's hours per row
4. Add ad-hoc rows for any project work

**"Weekly Standard" template rows:**
- Focussed time: Email and Teams messages (BAU) — gap fill
- Meetings - HR Systems team: Functional Analysts: regular catch-up — 0:15 daily
- Meetings - HR Systems team: Weekly H&S Roadmap update meeting — 1:00 Mondays
- Meetings - HR Systems team: Functional Analysts: one-to-ones — when 1-1s occur

**Important:** Do NOT attempt Clockify API writes. Kevin's Oxford SSO account cannot authenticate for POSTs. Timesheet UI is the solution. See HANDOVER_01June2026_FINAL.md for full detail.

---

## KEY PEOPLE

| Person | Role | Priority |
|--------|------|----------|
| Marie Cooksey | Kevin's boss, Head of HR Systems | Always immediate |
| Simon Burford | Covered Kevin in May, Analysis Manager | High |
| James Salas Guillen | Functional Analyst, direct report | Normal |
| Crispin Muncaster | IT Services PM, DTP1092 | Normal |
| Conor O'Brien | Access Group, back 11 June | Normal |

---

## TONE & STYLE
- Friendly but professional. Warm, not stiff.
- Kevin is direct — don't over-explain. Get to the point.
- He's just back from medical leave — be supportive but not fussy about it.
- He's tech-savvy and building real tools — treat him as a peer.

---

## TOOLS AVAILABLE
- **Chrome extension** (BEGB0037) — for browser automation, Outlook, Clockify
- **File system** — `C:\Users\begb0037.AD-OAK\Work Folders\Documents\Claude\` mounted
- **Cowork** — for heavy multi-step tasks (research, long-form builds)
- **Claude Code** — for AIMM/code work

---

## AIMM FAILOVER CHAIN
**Kevin → Hope → Adam → Work → Admin**  
If any seat hits usage cap mid-task, move immediately to next seat. Share the handover file path. Do not re-explain — just say "read HANDOVER_01June2026_FINAL.md from outputs."

---

## FILES TO KNOW ABOUT
- `HANDOVER_01June2026_FINAL.md` — full session detail, Clockify IDs, mapping engine
- `command_centre_refreshed.html` — current CC (needs redesign)
- `Briefing_01_June_2026.md` — in Kevin's Work Folders, full inbox brief

---

*Cold start written end of 1 June session. Good morning, Kevin.*
