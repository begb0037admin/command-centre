# HANDOVER — 1 June 2026 (Full session, end of day)
**From:** Kevin (Lead) seat  
**To:** Next seat in AIMM chain  
**AIMM failover chain:** Kevin → Hope → Adam → Work → Admin  
**Priority on next session:** Command Centre UI redesign + Clockify weekly template refinement

---

## AIMM seat protocol reminder
If usage caps mid-task, move immediately to the next seat. Pass this document. Do not re-explain context — just share the file path and say "read the handover". The next seat reads HANDOVER POINT at top of CLAUDE.md for AIMM project, or this file for inbox/Clockify work.

---

## What was accomplished today (1 June 2026)

### Kevin's situation
- First day back from 4-week medical leave (surgery ~5 May, tendon/scar tissue complications)
- Simon Burford covered throughout May
- Occupational health referral sent — phased return may apply
- Today was catching up on a month of email/inbox

### Completed this session
✅ Full inbox briefing for May 2026 (from Hope seat, saved to Work Folders)  
✅ Command Centre updated — leave banner removed, "Log Today" button added, dynamic greeting  
✅ Clockify full project/task structure pulled and mapped (139 projects, all tasks)  
✅ Apr 27–May 1 reference week read — mapping engine built from real historical data  
✅ Jun 1 calendar events identified and mapped  
✅ Clockify API auth fully investigated — SSO blocker confirmed (see below)  
✅ Timesheet approach discovered and adopted — FAR better than Time Tracker automation  
✅ Today's time entries posted (7h 15m — see below)  
✅ "Weekly Standard" Clockify template created and saved in Clockify  
✅ Command Centre HTML file updated and saved to outputs

---

## CLOCKIFY — THE SOLUTION (critical — read carefully)

### The auth situation (do not re-investigate)
Kevin's Oxford account uses Microsoft SSO → CAKE.com → Clockify. This makes programmatic API write access impossible:
- API keys return "Token is not valid" — SSO accounts not supported for API writes
- Session JWT returns 500 on POST — read-only token
- Internal app cookie auth — "multiple tokens" conflict

**Decision: Use Clockify Timesheet UI, not Time Tracker, not API. This is the correct long-term approach.**

### The Timesheet approach (what actually works)

Kevin discovered the Timesheet view is far superior to the Time Tracker for bulk logging. Key facts:

1. **Timesheet is at** `https://app.clockify.me/timesheet`
2. **Each row = one project+task combination** across the whole week
3. **You enter duration per day** (not start/end times) — this is fine for non-meeting entries
4. **Tasks ARE selectable** — click project row → picker opens → click Tasks count → click arrow to expand → scroll to task → click it
5. **Templates save the row structure** — Apply template = one click to populate all standard rows

### The "Weekly Standard" template (already saved in Clockify)
Template name: **Weekly Standard**  
Contains these 4 rows (project > task):

| Row | Project | Task | Typical daily hours |
|-----|---------|------|---------------------|
| 1 | Focussed time: Email and Teams messages (BAU) | — | Varies (gap fill) |
| 2 | Meetings - HR Systems team (Meetings) | Functional Analysts: regular catch-up | 0:15 Mon–Fri |
| 3 | Meetings - HR Systems team (Meetings) | Weekly H&S Roadmap update meeting | 1:00 Mon only |
| 4 | Meetings - HR Systems team (Meetings) | Functional Analysts: one-to-ones | 1:00 (when 1-1 occurs) |

**Additional rows to add as needed (not in template — vary week to week):**
- HR Systems Management Team meeting (Wed) → Meetings - HR Systems team > HR Systems Management Team meeting
- Simon/Kevin 121s (Wed) → Meetings - HR Systems team > HR Systems Management Team: one-to-ones
- Project work (DTP1092, Roadmap, FA Team activities) → relevant project, as they occur

### Today's entries posted (Mon 1 June 2026)
| Project > Task | Duration |
|---|---|
| Focussed time: Email and Teams messages | 5:00 |
| Meetings - HR Systems team: Functional Analysts: regular catch-up | 0:15 |
| Meetings - HR Systems team: Weekly H&S Roadmap update meeting | 1:00 |
| Meetings - HR Systems team: Functional Analysts: one-to-ones | 1:00 |
| **Total** | **7:15** |

Note: The Meetings entries (catchup, H&S, 1-1) were calendar events from Outlook sync but entered as Timesheet durations. Outlook sync auto-populates meetings in the Calendar view — Timesheet is the manual layer on top.

### Daily Clockify process (the target workflow)

**Each evening (takes ~2 minutes):**
1. Open `https://app.clockify.me/timesheet`
2. If Monday: click **Apply** on "Weekly Standard" template → rows populate
3. Fill in each row's duration for today (in the correct day column)
4. Add any ad-hoc project rows that came up (project work, unusual meetings)
5. Done

**For the "Log Today" Command Centre button — next steps:**
The button currently sends `sendPrompt('Log today to Clockify')`. When triggered, Claude should:
1. Ask Kevin what he worked on (or check calendar via Chrome)
2. Map to correct rows
3. Tell Kevin what to enter in each Timesheet cell
4. Kevin enters and saves

This is still faster than manual — Claude does the thinking, Kevin does 5 clicks.

---

## COMMAND CENTRE — needs redesign (next priority)

### Current state
File: `command_centre_refreshed.html` (saved to outputs and to Kevin's Work Folders)  
Kevin described it as "very clunky, very old" — needs a full UI refresh.

### What needs changing
1. **Visual design** — full redesign. More modern, cleaner. Kevin's aesthetic from AIMM (dark/rich look) could inform this.
2. **Content** — currently shows Apr/May data (handover prep, leave countdown). Needs updating to June week.
3. **Open actions** — should reflect Kevin's current June actions (not May handover tasks)
4. **Meetings panel** — needs this week's meetings (Jun 2 week)
5. **Launch buttons** — keep Morning Briefing, VIP Check, Calendar Check. Replace "Meeting review (Granola)" with something relevant. Keep "⏱ Log Today".
6. **Clockify panel** — consider adding a "This week" summary panel showing hours logged so far

### Kevin's current open actions (from inbox briefing)
1. 🔴 RSVP Eploy Hold meeting — Tue 2 June 11am
2. 🔴 FlexPoints case #68899229 — authorise in portal before 11 June
3. 🔴 Chase Marie for PXD DPIA sign-off before 5 June
4. 🔴 Chase Marie for DTP1092 proposal sign-off before 5 June
5. 🔴 Teams Telephony deadline — check with Marie/Neil Clarke (passed today)
6. 🟡 Design session booked: Command Centre v2 — tomorrow (2 June)

### Design direction for Command Centre v2
- Keep the card-based layout but modernise
- Consider a sidebar or top-bar for quick stats (hours logged this week, emails in inbox, next meeting)
- The Launch Assistant buttons are the most-used feature — make them more prominent
- Consider a daily "Today at a glance" section at the top
- Remove Granola references (no longer used)
- The HTML should still work as a Claude artifact (inline CSS/JS, no external dependencies except cdnjs)

---

## KEY PEOPLE / RELATIONSHIPS

| Person | Role | Notes |
|--------|------|-------|
| Marie Cooksey | Head of HR Systems, Kevin's boss | Always surface immediately |
| Simon Burford | HR Systems Analysis Manager | Covered Kevin in May |
| Crispin Muncaster | IT Services PM | DTP1092 project |
| Conor O'Brien | Access Group | Back from leave 11 June |
| James Salas Guillen | Functional Analyst (direct report) | 1-1 sessions |

---

## CLOCKIFY PROJECT/TASK REFERENCE (confirmed IDs)

| Project | Category | Project ID |
|---------|----------|------------|
| Focussed time: Email and Teams messages | BAU | 64c0e2483c2c4542c2edeb66 |
| Meetings - HR Systems team | Meetings | 699d6c7c667a5341a63a04e1 |
| Functional Analyst Team activities | BAU | (look up if needed) |
| HR Systems Roadmap updates | BAU | (look up if needed) |
| Research management data for REF [DTP1092] | Funded Projects | (look up if needed) |

| Task (Meetings - HR Systems team) | Task ID |
|-----------------------------------|---------|
| Functional Analysts: regular catch-up | 699d70ea667a5341a63aaffa |
| Weekly H&S Roadmap update meeting | 699f08eca11ae720eecb7c97 |
| Functional Analysts: one-to-ones | 699d71e2afa57c90cad91bbc |

---

## CLOCKIFY TIMESHEET — HOW TO SELECT A TASK (step by step for next seat)

This caused a lot of confusion — document it clearly:

1. Go to Timesheet
2. Click "Add new row" → "Select project" appears
3. Click "Select project" → picker opens
4. Find "Meetings - HR Systems team" → click **the arrow (∨) to the right of "N Tasks"** — this expands the task list
5. Tasks appear below — **scroll within the dropdown** to find the right task
6. Click the task name → row updates to show "Project: Task"
7. Enter hours in the day cells

**Key gotcha:** The arrow is a `<select-arrow>` element inside a `button.cl-btn-link`. Clicking the task count badge selects the project without a task. Clicking the arrow expands tasks inline. If automating, use JS: `meetingsBtn.querySelector('select-arrow').click()` then `scrollIntoView` and `.click()` on the target task's `.cl-dropdown-item`.

---

## CLOCKIFY MAPPING ENGINE (from historical data)

**Built from Apr 27–May 3 reference week. Reliable patterns:**

| Calendar event | Project | Task | Duration |
|---------------|---------|------|----------|
| FA Team Daily Catchup | Meetings - HR Systems team | Functional Analysts: regular catch-up | 0:15 every weekday |
| H&S Roadmap | Meetings - HR Systems team | Weekly H&S Roadmap update meeting | 1:00 Mondays |
| 1-1 Session / [Name] 1-1 | Meetings - HR Systems team | Functional Analysts: one-to-ones | 0:30 or 1:00 |
| Simon / Kevin 121s | Meetings - HR Systems team | HR Systems Management Team: one-to-ones | 1:00 Wednesdays |
| HR Systems team meeting | Meetings - HR Systems team | HR Systems Management Team meeting | 1:00 Wednesdays |
| DTP1092 work | Research management data for REF [DTP1092] | — | as per calendar |
| Roadmap review | HR Systems Roadmap updates | — | as per calendar |
| FA Team activities | Functional Analyst Team activities | — | as per calendar |
| Gap fill (all other time) | Focussed time: Email and Teams messages | — | remaining hours |

---

## FILES SAVED TODAY

| File | Location | Notes |
|------|----------|-------|
| HANDOVER_01June2026_FINAL.md | /mnt/user-data/outputs/ | This file |
| COLDSTART_02June2026.md | /mnt/user-data/outputs/ | Morning brief for Kevin |
| command_centre_refreshed.html | /mnt/user-data/outputs/ | Updated CC — needs redesign |
| Briefing_01_June_2026.md | C:\Users\begb0037.AD-OAK\Work Folders\Documents\Claude\Master Prompt AI Inbox & Calendar Assistant\ | Full inbox briefing |

---

## WORKSPACE / TECH INFO

| Item | Value |
|------|-------|
| Clockify workspace | HR Systems workspace |
| Clockify workspace ID | 64be71d996d0922209171f18 |
| Clockify user ID | 6728e441b3c33e77581a9892 |
| Clockify email | kevin.lelitte@admin.ox.ac.uk |
| Chrome browser name | BEGB0037 |
| Clockify Timesheet URL | https://app.clockify.me/timesheet |
| Clockify Tracker URL | https://app.clockify.me/tracker |
| Command Centre (live) | https://begb0037admin.github.io/trap-master-reference/ |
| AIMM repo | ~/Documents/Claude/Artifacts/trap-master-reference/ |

---

*Handover written end of session 1 June 2026. Next seat: start with Command Centre v2 redesign. Kevin's design brief is: modern, clean, not clunky. Use the frontend-design skill.*
